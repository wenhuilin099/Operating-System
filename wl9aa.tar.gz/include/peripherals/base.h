#ifndef	_P_BASE_H
#define	_P_BASE_H

#define PBASE 0x3F000000

#endif  /*_P_BASE_H */
